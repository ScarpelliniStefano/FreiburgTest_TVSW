package libFST;

import static org.junit.Assert.*;

import org.junit.Test;
import libFST.test_freiburg.ModelTestContext;

public class Full_test {

	@Test
	public void test() {
		test_freiburg modeltest = new test_freiburg();
	    modeltest.run();
	    
		
	}

}
